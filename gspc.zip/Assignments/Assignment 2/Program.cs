﻿using System.Linq.Expressions;
using System;
using System.Collections.Generic;
using System.Linq;
using ExtensionMethods;
using System.Collections;

namespace Assignment_2
{
    class Program
    {
        static void Main(string[] args)
        {

// 1. Guid
            var players = Instantiate(1000000);

            if (players.Length != players.Distinct().Count())
            {
                Console.WriteLine("Contains duplicates");
            }

// 2. Extension method
            Console.WriteLine("\n2. Extension method:");

            var dummy = players[0];

            var rand = new Random();

            for (int i = 0; i < 10; i++)
            {
                var item = new Item();
                item.Id = Guid.NewGuid();
                item.Level = rand.Next(100);
                dummy.Items.Add(item);
            }

            Console.WriteLine("Highest level item: {0}", dummy.GetHighestLevelItem().Level);

// 3. LINQ
            Console.WriteLine("\n3. LINQ:");

            Console.WriteLine("Item levels: [{0}]",  string.Join(",", GetItems(dummy).Select(x => x.Level)));

            Console.WriteLine("Item levels with linq: [{0}]",  string.Join(",", GetItemsWithLinq(dummy).Select(x => x.Level)));
            
// 4. LINQ 2
            Console.WriteLine("\n4. LINQ 2:");

            for (int i = 1; i >= 0; --i)
            {
                try
                {
                    Console.WriteLine("First item: {0}", FirstItem(players[i]).Level);
                }
                catch (System.NullReferenceException)
                {
                    Console.WriteLine("Player has no items");
                }

                try
                {
                    Console.WriteLine("First item with linq: {0}", FirstItemWithLinq(players[i]).Level);
                }
                catch (System.NullReferenceException)
                {
                    Console.WriteLine("Player has no items");
                }
            }

// 5. Delegates
            Console.WriteLine("\n5. Delegates:");

            ProcessEachItem(dummy, PrintItem);

// 6. Lambda
            Console.WriteLine("\n6. Lambda:");

            ProcessEachItem(dummy, item => Console.WriteLine("{0} : {1}", item.Id, item.Level));

// 7. Generics
            Console.WriteLine("\n7. Generics:");

            var game = new Game<Player>(Instantiate(100).ToList());

            Console.WriteLine("Game: [{0}]",  string.Join(",", game.GetTop10Players().Select(x => x.Score)));

            var anotherGame = new Game<PlayerFromAnotherGame>(
                new PlayerFromAnotherGame[5]
                .Select(x => {
                    x = new PlayerFromAnotherGame();
                    x.Score = rand.Next(1000); 
                    return x;
                    }).ToList());

            Console.WriteLine("Another game: [{0}]",  string.Join(",", anotherGame.GetTop10Players().Select(x => x.Score)));
        }

        static Player[] Instantiate(int amount)
        {
            var players = new Player[amount];

            var rand = new Random();

            for (int i = 0; i < players.Length; i++)
            {
                players[i] = new Player();
                players[i].Score = rand.Next(100);
                players[i].Id = Guid.NewGuid();
                players[i].Items = new List<Item>();
            }

            return players;
        }

        static Item[] GetItems(Player player)
        {
            var items = new Item[player.Items.Count];

            for (int i = 0; i < items.Length; i++)
            {
                items[i] = player.Items[i];
            }

            return items;
        }

        static Item[] GetItemsWithLinq(Player player)
        {
            return player.Items.ToArray();
        }

        static Item FirstItem(Player player)
        {
            return player.Items.Count > 0 ? player.Items[0] : null;
        }

        static Item FirstItemWithLinq(Player player)
        {
            return player.Items.FirstOrDefault();
        }

        static void ProcessEachItem(Player player, Action<Item> process)
        {
            player.Items.ForEach(item => process(item));
        }

        static void PrintItem(Item item)
        {
            Console.WriteLine("{0} : {1}", item.Id, item.Level);
        }
    }
}

namespace Assignment_2
{
    public interface IPlayer
    {
         int Score { get; set; }
    }
}
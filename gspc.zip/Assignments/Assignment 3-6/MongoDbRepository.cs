using System;
using System.Threading.Tasks;
using MongoDB.Driver;
using MongoDB.Bson;
using System.Linq;
using System.Collections.Generic;

public class MongoDbRepository : IRepository
{
    private readonly IMongoCollection<Player> _collection;
    private readonly IMongoCollection<BsonDocument> _bsonDocumentCollection;

    public MongoDbRepository()
    {
        var mongoClient = new MongoClient("mongodb://localhost:27017");
        var database = mongoClient.GetDatabase("game");
        _collection = database.GetCollection<Player>("players");
        _bsonDocumentCollection = database.GetCollection<BsonDocument>("players");
    }

    public void DeleteAll()
    {
        _collection.DeleteMany(new BsonDocument());

    }

    public async Task<Player> CreatePlayer(Player player)
    {
        await _collection.InsertOneAsync(player);
        return player;
    }

    public async Task<Player[]> GetAllPlayers(int? minScore)
    {
        List<Player> players;

        if (minScore != null)
        {
            Console.WriteLine("minScore! " + minScore);
            var filter = Builders<Player>.Filter.Gt(p => p.Score, minScore);
            players = await _collection.Find(filter).ToListAsync();
        }
        else
        {
            players = await _collection.Find(new BsonDocument()).ToListAsync();
        }

        return players.ToArray();
    }

    public Task<Player> GetPlayer(Guid id)
    {
        var filter = Builders<Player>.Filter.Eq(p => p.Id, id);
        return _collection.Find(filter).FirstOrDefaultAsync();
    }

    public async Task<Player> UpdatePlayer(Player player)
    {
        FilterDefinition<Player> filter = Builders<Player>.Filter.Eq(p => p.Id, player.Id);
        await _collection.ReplaceOneAsync(filter, player);
        return player;
    }

    public async Task<Player> DeletePlayer(Guid playerId)
    {
        FilterDefinition<Player> filter = Builders<Player>.Filter.Eq(p => p.Id, playerId);
        return await _collection.FindOneAndDeleteAsync(filter);
    }

    public async Task<Item> CreateItem(Guid playerId, Item item)
    {
        Player player = await GetPlayer(playerId);
        if (player == null)
            throw new NotFoundException("incorrect {playerId} passed in the route");

        if (item.Type == ItemType.SWORD && player.Level < 3)
            throw new LevelTooLowException("Level too low.");

        player.Items.Add(item);

        await UpdatePlayer(player);

        return item;
    }

    public async Task<Item> GetItem(Guid playerId, Guid itemId)
    {
        Player player = await GetPlayer(playerId);
        if (player == null) return null;

        return player.Items.Find(x => x.Id == itemId);
    }

    public async Task<Item[]> GetAllItems(Guid playerId)
    {
        Player player = await GetPlayer(playerId);
        if (player == null) return null;

        return player.Items.ToArray();
    }

    public async Task<Item> UpdateItem(Guid playerId, Item item)
    {
        Player player = await GetPlayer(playerId);
        if (player == null) return null;

        int i = player.Items.FindIndex(x => x.Id == item.Id);
        if (i < 0) return null;

        player.Items[i] = item;
        await UpdatePlayer(player);
        return item;
    }

    public async Task<Item> DeleteItem(Guid playerId, Guid itemId)
    {
        Player player = await GetPlayer(playerId);
        if (player == null) return null;

        Item item = await GetItem(playerId, itemId);
        player.Items = player.Items.Where(x => x.Id != itemId).ToList();
        await UpdatePlayer(player);
        return item;
    }

    public Task<Player> GetWithName(string name)
    {
        var filter = Builders<Player>.Filter.Eq(p => p.Name, name);
        return _collection.Find(filter).FirstOrDefaultAsync();
    }

    public async Task<Player[]> GetTagged(Tag tag)
    {
        var filter = Builders<Player>.Filter.Eq("Tags", tag);
        var players = await _collection.Find(filter).ToListAsync();
        return players.ToArray();
    }

    public Task<Player> GetWithCount(int itemCount)
    {
        var filter = Builders<Player>.Filter.Size(p => p.Items, itemCount);
        return _collection.Find(filter).FirstOrDefaultAsync();
    }
}

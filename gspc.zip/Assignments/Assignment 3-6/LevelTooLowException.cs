using System;

public class LevelTooLowException : Exception
{
    public LevelTooLowException(String message) : base(message) {}
}
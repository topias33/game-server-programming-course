using System;
using System.IO;
using System.Threading.Tasks;
using Newtonsoft.Json;
using System.Collections.Generic;
using System.Linq;

public class FileRepository : IRepository
{
    public string path = "game-dev.txt";

    public FileRepository()
    {
        WritePlayers(new List<Player>());
    }

    List<Player> ReadPlayers()
    {
        return JsonConvert.DeserializeObject<List<Player>>(File.ReadAllText(path));
    }

    void WritePlayers(List<Player> players)
    {
        File.WriteAllText(path, JsonConvert.SerializeObject(players));
    }

    public async Task<Player> CreatePlayer(Player player)
    {
        var players = ReadPlayers();
        if (players == null) return null;        
        players.Add(player);
        WritePlayers(players);
        return player;
    }

    public async Task<Player> GetPlayer(Guid playerId)
    {
        var players = ReadPlayers();
        if (players == null)
            return null;
        return players.Find(x => x.Id == playerId);
    }

    public async Task<Player[]> GetAllPlayers(int? minScore)
    {
        var players = ReadPlayers();
        if (players == null)
            return null;
        return players.ToArray();
    }

    public async Task<Player> UpdatePlayer(Player player)
    {
        var players = ReadPlayers();
        if (players == null)
            return null;

        var i = players.FindIndex(x => x.Id == player.Id);
        if (i < 0) return null;

        players[i] = player;

        WritePlayers(players);
        return players[i];
    }

    public async Task<Player> DeletePlayer(Guid playerId)
    {
        var players = ReadPlayers();
        if (players == null)
            return null;
        Player player = await GetPlayer(playerId);
        players = players.Where(x => x.Id != playerId).ToList();
        WritePlayers(players);
        return player;
    }

    public async Task<Item> CreateItem(Guid playerId, Item item)
    {
        Player player = await GetPlayer(playerId);
        if (player == null) 
            throw new NotFoundException("incorrect {playerId} passed in the route");

        if (item.Type == ItemType.SWORD && player.Level < 3)
            throw new LevelTooLowException("Level too low.");
        
        player.Items.Add(item);
        
        await UpdatePlayer(player);

        return item;
    }

    public async Task<Item> GetItem(Guid playerId, Guid itemId)
    {
        Player player = await GetPlayer(playerId);
        if (player == null) return null;

        return player.Items.Find(x => x.Id == itemId);
    }

    public async Task<Item[]> GetAllItems(Guid playerId)
    {
        Player player = await GetPlayer(playerId);
        if (player == null) return null;

        return player.Items.ToArray();
    }

    public async Task<Item> UpdateItem(Guid playerId, Item item)
    {
        Player player = await GetPlayer(playerId);
        if (player == null) return null;

        int i = player.Items.FindIndex(x => x.Id == item.Id);
        if (i < 0) return null;

        player.Items[i] = item;
        await UpdatePlayer(player);
        return item;
    }

    public async Task<Item> DeleteItem(Guid playerId, Guid itemId)
    {
        Player player = await GetPlayer(playerId);
        if (player == null) return null;

        Item item = await GetItem(playerId, itemId);
        player.Items = player.Items.Where(x => x.Id != itemId).ToList();
        await UpdatePlayer(player);
        return item;
    }

    public Task<Player> GetWithName(string name)
    {
        throw new NotImplementedException();
    }

    public void DeleteAll()
    {
        throw new NotImplementedException();
    }

    public Task<Player[]> GetTagged(Tag tag)
    {
        throw new NotImplementedException();
    }

    public Task<Player> GetWithCount(int itemCount)
    {
        throw new NotImplementedException();
    }
}
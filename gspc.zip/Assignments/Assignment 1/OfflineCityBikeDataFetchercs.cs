using System;
using System.Linq;
using System.Threading.Tasks;

namespace Assignment_1
{
    public class OfflineCityBikeDataFetcher : ICityBikeDataFetcher
    {
        public Task<int> GetBikeCountInStation(string stationName)
        {
            if (stationName.Any(char.IsDigit))
            {
                throw new System.ArgumentException("Station name may not have numbers.");
            }

            string[] lines = System.IO.File.ReadAllLines("bikedata.txt");

            foreach (var line in lines)
            {
                var station = line.Split(" : ");
                
                if(station[0] == stationName)
                    return Task.FromResult(Int32.Parse(station[1]));
            }

            throw new NotFoundException("Station not found.");
        }
    }
}
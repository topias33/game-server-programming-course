using System;

[Serializable]
public class Game
{
    public string Id {get; set;}
    public int Round {get; set;}
    public long LastDate {get; set;}
    public bool IsFinished {get; set;} 

    public string Username_A {get; set;}
    public string Username_B {get; set;}

    public string ShipsString_A {get; set;}
    public string HitsString_A {get; set;}

    public string ShipsString_B {get; set;}
    public string HitsString_B {get; set;}
}
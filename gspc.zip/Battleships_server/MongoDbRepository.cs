using MongoDB.Driver;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;

public class MongoDbRepository : IRepository
{
    private readonly IMongoCollection<Player> playerCollection;
    private readonly IMongoCollection<Game> gameCollection;

    public MongoDbRepository()
    {
        var mongoClient = new MongoClient("mongodb://localhost:27017");
        var database = mongoClient.GetDatabase("battleships");
        playerCollection = database.GetCollection<Player>("players");
        gameCollection = database.GetCollection<Game>("games");
    }

    async Task<Player> FindPlayer(string username)
    {
        var filter = Builders<Player>.Filter.Eq(p => p.Username, username);
        return await playerCollection.Find(filter).FirstOrDefaultAsync();
    }

    public async Task<Player> CreatePlayer(string username, string password)
    {
        var player = await FindPlayer(username);
        if (player == null)
        {
            player = new Player(username, password);
            await playerCollection.InsertOneAsync(player);
            return player;
        }
        return null;
    }

    public async Task<Player> LoginPlayer(string username, string password)
    {
        Player player = await FindPlayer(username);

        if (player != null && player.Password == password)
            return player;
        return null;
    }

    public async Task<GameList> GetGames(string username)
    {
        var f = Builders<Game>.Filter;
        var filter = f.Or(f.Eq(g => g.Username_A, username), f.Eq(g => g.Username_B, username));
        return new GameList(await gameCollection.Find(filter).ToListAsync());
    }

    public async void UpdateGame(Game game)
    {
        var filter = Builders<Game>.Filter.Eq(g => g.Id, game.Id);

        if (await gameCollection.Find(filter).FirstOrDefaultAsync() != null)
        {
            await gameCollection.ReplaceOneAsync(filter, game);
        }
        else
        {
            await gameCollection.InsertOneAsync(game);
        }
    }

    public async Task<Game> FindNewGame(string username)
    {
        var f = Builders<Game>.Filter;
        var game = await gameCollection.Find
        (
            f.And
            (
                f.Eq(g => g.IsFinished, false),
                f.Eq(g => g.Username_B, ""),
                f.Not(f.Eq(g => g.Username_A, username))
            )
        ).FirstOrDefaultAsync();

        return game;
    }

    public async void DeleteGame(string username)
    {
        var f = Builders<Game>.Filter;
        var filter = f.Or(f.Eq(g => g.Username_A, username), f.Eq(g => g.Username_B, username));
        await gameCollection.DeleteOneAsync(filter);
    }
}
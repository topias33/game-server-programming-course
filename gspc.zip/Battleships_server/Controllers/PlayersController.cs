﻿using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;

namespace Battleships_server.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class PlayersController : ControllerBase
    {
        IRepository repository;

        public PlayersController(IRepository repository) => this.repository = repository;

        // GET api/players/{username}/{password}
        [HttpGet("{username}/{password}")]
        public Task<Player> Get(string username, string password) => repository.LoginPlayer(username, password);

        // POST api/players/{username}/{password}
        [HttpPost("{username}/{password}")]
        public Task<Player> Post(string username, string password) => repository.CreatePlayer(username, password);
    }
}

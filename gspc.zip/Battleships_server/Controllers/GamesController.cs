﻿using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json;

namespace Battleships_server.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class GamesController : ControllerBase
    {
        IRepository repository;

        public GamesController(IRepository repository) => this.repository = repository;

        // GET api/games/{username}
        [HttpGet("{username}")]
        public Task<GameList> GetGames(string username) => repository.GetGames(username);

        // PUT api/games/{game}
        [HttpPut("{json}")]
        public void UpdateGame(string json) => repository.UpdateGame(JsonConvert.DeserializeObject<Game>(json));

        // POST api/games/{username}
        [HttpPost("{username}")]
        public Task<Game> FindNewGame(string username) => repository.FindNewGame(username);

        [HttpDelete("{username}")]
        public void DeleteGame(string username) => repository.DeleteGame(username);
    }
}

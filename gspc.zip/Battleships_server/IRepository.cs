using System.Threading.Tasks;

public interface IRepository
{
    // PlayersController
    Task<Player> CreatePlayer(string username, string password);
    Task<Player> LoginPlayer(string username, string password);

    // GamesController
    Task<GameList> GetGames(string username);
    void UpdateGame(Game game);
    Task<Game> FindNewGame(string username);
    void DeleteGame(string username);
}
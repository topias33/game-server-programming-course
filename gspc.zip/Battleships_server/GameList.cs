﻿using System;
using System.Collections.Generic;

[Serializable]
public class GameList
{
    public List<Game> games;

    public GameList(List<Game> games) => this.games = games;
}
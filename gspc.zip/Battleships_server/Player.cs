using System;
using System.Collections.Generic;

[Serializable]
public class Player
{
    public Guid Id {get; set;}
    public string Username {get; set;}
    public string Password {get; set;}

    public Player(string username, string password) 
    {
        Username = username; 
        Password = password;

        Id = Guid.NewGuid();
    }
}
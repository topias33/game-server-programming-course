﻿public interface IState
{
    void OnEnableState();
    void OnDisableState();
}
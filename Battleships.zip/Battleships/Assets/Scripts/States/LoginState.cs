﻿using UnityEngine;
using UnityEngine.Networking;
using UnityEngine.UI;

class LoginState : MonoBehaviour, IState
{
    public GameObject nextState;

    public Text username;
    public Text password;

    public Button login;
    public Button signup;

    public GameObject redText;

    StateMachine sm;

    bool coroutineInProgress;

    bool isReady;

    public void OnEnableState()
    {
        sm = GetComponentInParent<StateMachine>();
        login.onClick.AddListener(() => LoginPlayer(username.text, password.text));
        signup.onClick.AddListener(() => CreatePlayer(username.text, password.text));

        redText.SetActive(false);
        isReady = false;
        login.interactable = false;
        signup.interactable = false;
        gameObject.SetActive(true);
    }

    public void OnDisableState()
    {
        gameObject.SetActive(false);
    }

    void Update()
    {
        bool isInteractable = !coroutineInProgress && username.text.Length > 0 && password.text.Length > 0;
        login.interactable = isInteractable;
        signup.interactable = isInteractable;
    }

    void LogWarning(string message)
    {
        redText.GetComponent<Text>().text = message;
        redText.SetActive(true);
    }

    void LoginPlayer(string username, string password)
    {
        if (!coroutineInProgress)
        {
            coroutineInProgress = true;

            var route = string.Format("http://localhost:5000/api/players/{0}/{1}", username, password);
            StartCoroutine(sm.pm.Lookup<Player>(UnityWebRequest.Get(route), player =>
            {
                if (player != null)
                {
                    Debug.Log("Login: Successful");
                    sm.player = username;
                    sm.ChangeState(nextState);
                }
                else
                {
                    Debug.Log("Login: Failed");
                    LogWarning("Username and/or Password is incorrect.");
                }
                coroutineInProgress = false;
            }));
        }
    }

    void CreatePlayer(string username, string password)
    {
        if (!coroutineInProgress)
        {
            coroutineInProgress = true;

            var route = string.Format("http://localhost:5000/api/players/{0}/{1}", username, password);
            StartCoroutine(sm.pm.Lookup<Player>(UnityWebRequest.Post(route, ""), player =>
            {
                if (player != null)
                {
                    Debug.Log("Sign up: Successful");
                    sm.player = username;
                    sm.ChangeState(nextState);
                }
                else
                {
                    Debug.Log("Sign up: Failed");
                    LogWarning("Username is taken.");
                }
                coroutineInProgress = false;
            }));
        }
    }
}
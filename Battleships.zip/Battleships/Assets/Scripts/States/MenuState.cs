using System;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Networking;
using UnityEngine.UI;

class MenuState : MonoBehaviour, IState
{
    public GameObject shipPlacementState;
    public GameObject gameState;
    public GameObject loginState;

    public GameObject gamePanelPrefab;
    public Transform gamePanels;

    public Button startNewGame;
    public Button refresh;
    public Button logout;

    StateMachine sm;

    bool coroutineInProgress;

    List<Game> games;

    public void OnEnableState()
    {
        sm = GetComponentInParent<StateMachine>();

        startNewGame.onClick.AddListener(StartGame);
        refresh.onClick.AddListener(GetGames);
        logout.onClick.AddListener(() => sm.ChangeState(loginState));

        gameObject.SetActive(true);
        GetGames();
    }

    public void OnDisableState()
    {
        games = new List<Game>();

        foreach (Transform child in gamePanels)
        {
            Destroy(child.gameObject);
        }

        gameObject.SetActive(false);

        gamePanels.parent.gameObject.SetActive(false);
    }

    void Update()
    {
        if (!coroutineInProgress)
        {
            if (!refresh.IsInteractable())
            {
                refresh.interactable = true;

                foreach (Transform child in gamePanels)
                {
                    Destroy(child.gameObject);
                }

                foreach (var game in games)
                {
                    var panel = Instantiate(gamePanelPrefab, gamePanels);
                    var gp = panel.GetComponent<GamePanel>();
                    gp.opponentText.text = game.GetOpponentName(sm.player);
                    gp.roundText.text = "Round: " + game.round;
                    gp.timeText.text = game.GetMinutes() + " minutes ago";

                    if (game.IsMyTurn(sm.player))
                    {
                        gp.playButton.interactable = true;
                        gp.playText.SetActive(true);
                        gp.waitText.SetActive(false);
                    }
                    else
                    {
                        gp.playButton.interactable = false;
                        gp.playText.SetActive(false);
                        gp.waitText.SetActive(true);
                    }

                    gp.playButton.onClick.AddListener(() =>
                    {
                        game.ConvertData(false);
                        sm.game = game;
                        sm.ChangeState(gameState);
                    });
                }

                gamePanels.parent.gameObject.SetActive(gamePanels.childCount > 0);
            }
        }
    }

    void GetGames()
    {
        if (!coroutineInProgress)
        {
            coroutineInProgress = true;
            refresh.interactable = false;

            var route = "http://localhost:5000/api/games/" + sm.player;
            StartCoroutine(sm.pm.Lookup<GameList>(UnityWebRequest.Get(route), gameList =>
            {
                games = gameList.games;
                coroutineInProgress = false;
            }));
        }
    }

    void StartGame()
    {
        if (!coroutineInProgress)
        {
            coroutineInProgress = true;

            var route = "http://localhost:5000/api/games/" + sm.player;
            StartCoroutine(sm.pm.Lookup<Game>(UnityWebRequest.Post(route, ""), game =>
            {
                if (game != null)
                {
                    game.ConvertData(false);
                    game.username_B = sm.player;
                    sm.game = game;
                }
                else
                {
                    sm.game = new Game();
                    sm.game.id = Guid.NewGuid().ToString();
                    sm.game.username_A = sm.player;
                }

                coroutineInProgress = false;
                sm.ChangeState(shipPlacementState);
            }));
        }
    }
}
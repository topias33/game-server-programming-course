﻿using System.Collections.Generic;
using System.Linq;
using UnityEngine;
using UnityEngine.EventSystems;
using UnityEngine.UI;

public class ShipPlacementState : MonoBehaviour, IState
{
    public GameObject nextState;

    public GridGenerator grid;
    public Button ready;

    public ShipGenerator[] ships;

    StateMachine sm;

    bool _dragging;
    Transform _shipPart;
    Transform _ship;
    Vector3 _dragOffset;

    public void OnEnableState()
    {
        sm = GetComponentInParent<StateMachine>();
        ready.onClick.AddListener(() => sm.ChangeState(nextState));

        ready.interactable = false;
        gameObject.SetActive(true);
    }

    public void OnDisableState()
    {
        var board = new Board();

        foreach (var ship in ships)
        {
            foreach (var image in ship.images)
            {
                var xy = grid.GetNodeAtPosition(image.transform.position);

                board.ships[xy.x, xy.y] = (int)ship.GetComponent<ShipGenerator>().shipType + 1;
            }

            ship.Relocate();
        }

        sm.game.SetBoard(sm.player, board);

        gameObject.SetActive(false);
    }

    void Update() 
    {
        PositionShips();
        ready.interactable = ValidateShipPositions();
    }

    public void PositionShips()
    {
        if (Input.GetMouseButtonDown(0))
        {
            _shipPart = sm.GetTransformWithTagInPosition(Input.mousePosition, "Ship");

            if (_shipPart != null)
            {
                _dragging = true;
                _ship = _shipPart.GetComponentInParent<ShipGenerator>().transform;
                _ship.SetAsLastSibling();
                _dragOffset = _ship.position - Input.mousePosition;
            }
        }

        if (Input.GetMouseButtonDown(1))
        {
            if (_dragging)
            {
                _ship.RotateAround(_shipPart.position, Vector3.forward, -90);
                _dragOffset = _ship.position - Input.mousePosition;
            }
            else
            {
                var shipPart = sm.GetTransformWithTagInPosition(Input.mousePosition, "Ship");

                if (shipPart != null)
                {
                    var ship = shipPart.parent.parent;
                    ship.SetAsLastSibling();
                    ship.RotateAround(shipPart.position, Vector3.forward, -90);
                    ship.position = grid.GetNearestNodePosition(ship.position);
                }
            }
        }

        if (_dragging)
        {
            _ship.position = grid.GetNearestNodePosition(Input.mousePosition + _dragOffset);
        }

        if (Input.GetMouseButtonUp(0))
        {
            _dragging = false;
        }
    }

    bool ValidateShipPositions()
    {
        bool returnValue = true;

        foreach (var ship in ships)
        {
            foreach (var image in ship.images)
            {
                image.raycastTarget = false;

                var isValid = grid.IsInsideGrid(image.transform.position) && sm.GetTransformWithTagInPosition(image.transform.position, "Ship") == null;

                image.raycastTarget = true;

                image.color = isValid ? Color.green : Color.red;

                if (!isValid) returnValue = false;
            }
        }

        return returnValue;
    }
}
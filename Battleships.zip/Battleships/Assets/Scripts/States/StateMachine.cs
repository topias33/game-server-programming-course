﻿using System;
using System.Collections.Generic;
using System.Linq;
using UnityEngine;
using UnityEngine.EventSystems;

public class StateMachine : MonoBehaviour
{
    public GameObject startState;
    IState _state;

    public GridGenerator[] grids;
    public ShipGenerator[] ships;

    [Header("Current:")]
    public string player;
    public Game game;

    [HideInInspector]
    public Postman pm;

    void Start()
    {
        foreach (var g in grids)
        {
            g.Generate();
        }
        
        foreach (var s in ships)
        {
            s.Generate();
        }

        pm = GetComponent<Postman>();
        _state = startState.GetComponent<IState>();
        _state.OnEnableState();
    }

    public void ChangeState(GameObject stateObject)
    {
        var state = stateObject.GetComponent<IState>();

        if (state != null && _state != state)
        {
            _state.OnDisableState();
            _state = state;
            _state.OnEnableState();
        }
    }

    public Transform GetTransformWithTagInPosition(Vector3 position, string tag)
    {
        var pointer = new PointerEventData(EventSystem.current);

        pointer.position = position;

        var hitObjects = new List<RaycastResult>();

        EventSystem.current.RaycastAll(pointer, hitObjects);

        if (hitObjects.Count > 0)
        {
            var clickedObject = hitObjects.First().gameObject;

            if (clickedObject != null && clickedObject.CompareTag(tag))
            {
                return clickedObject.transform;
            }
        }

        return null;
    }
}

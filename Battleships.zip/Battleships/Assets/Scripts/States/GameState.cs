using System;
using UnityEngine;
using UnityEngine.Networking;
using UnityEngine.UI;

class GameState : MonoBehaviour, IState
{
    public GameObject nextState;
    public GameObject winState;
    public Button confirm;
    public GridGenerator myGrid;
    public GridGenerator opGrid;

    Image targetImage;
    StateMachine sm;

    Board myBoard;
    Board opBoard;

    bool coroutineInProgress;

    public void OnEnableState()
    {
        sm = GetComponentInParent<StateMachine>();
        confirm.interactable = false;
        confirm.onClick.AddListener(UpdateGame);

        gameObject.SetActive(true);

        myBoard = sm.game.GetBoard(sm.player);
        opBoard = sm.game.GetBoard(sm.game.GetOpponentName(sm.player));

        if (sm.game.round > 1)
        {
            var myWin = CheckWin(myBoard);
            var opWin = CheckWin(opBoard);

            if (myWin || opWin)
            {
                winState.GetComponent<WinState>().myWin = myWin;
                sm.ChangeState(winState);

                return;
            }
        }

        DisplayShips(myGrid, myBoard);
        DisplayHits(myGrid, myBoard);
        DisplayHits(opGrid, opBoard);
    }

    public void OnDisableState()
    {
        if (targetImage)
        {
            targetImage.color = Color.white;
            targetImage = null;
        }

        gameObject.SetActive(false);
    }

    void Update()
    {
        if (!coroutineInProgress)
        {
            Vector3Int nodePos = opGrid.GetNodeAtPosition(Input.mousePosition);

            if (Input.GetMouseButtonDown(0) && opGrid.IsInsideGrid(Input.mousePosition) && opBoard != null && opBoard.hits[nodePos.x, nodePos.y] == 0)
            {
                var node = sm.GetTransformWithTagInPosition(opGrid.GetNearestNodePosition(Input.mousePosition), "Select");
                if (node)
                {
                    if (targetImage)
                        targetImage.color = Color.white;
                    targetImage = node.GetComponent<Image>();
                }
            }

            if (targetImage)
                targetImage.color = Color.yellow;

            confirm.interactable = targetImage;
        }
    }

    void DisplayHits(GridGenerator grid, Board board)
    {
        if (board != null)
        {
            for (int x = 0; x < 10; x++)
            {
                for (int y = 0; y < 10; y++)
                {
                    if (board.hits[x, y] == 1)
                    {
                        grid.nodeImages[x * 10 + y].color = board.ships[x, y] > 0 ? Color.red : Color.black;
                    }
                }
            }
        }
    }

    void DisplayShips(GridGenerator grid, Board board)
    {
        if (board != null)
        {
            for (int x = 0; x < 10; x++)
            {
                for (int y = 0; y < 10; y++)
                {
                    grid.nodeImages[x * 10 + y].color = board.ships[x, y] > 0 ? Color.gray : Color.white;
                }
            }
        }
    }

    bool CheckWin(Board board)
    {
        for (int x = 0; x < 10; x++)
        {
            for (int y = 0; y < 10; y++)
            {
                if (board.ships[x, y] > 0 && board.hits[x, y] == 0)
                    return false;
            }
        }
        return true;
    }

    public void UpdateGame()
    {
        if (!coroutineInProgress)
        {
            coroutineInProgress = true;

            var hit = opGrid.GetNodeAtPosition(targetImage.transform.position);
            opBoard.hits[hit.x, hit.y] = 1;

            sm.game.SetBoard(sm.game.GetOpponentName(sm.player), opBoard);
            sm.game.round++;
            sm.game.ConvertData(true);
            sm.game.lastDate = DateTime.Now.Ticks;

            var route = "http://localhost:5000/api/games/" + JsonUtility.ToJson(sm.game);

            Debug.Log("Update: " + JsonUtility.ToJson(sm.game));

            StartCoroutine(sm.pm.Lookup<Game>(UnityWebRequest.Put(route, default(Byte[])), x =>
            {
                coroutineInProgress = false;
                sm.ChangeState(nextState);
            }));
        }
    }
}
using System;
using UnityEngine;
using UnityEngine.Networking;
using UnityEngine.UI;

class WinState : MonoBehaviour, IState
{
    public GameObject nextState;

    public bool myWin;

    public GameObject winText;
    public GameObject lostText;

    public Button continueButton;

    StateMachine sm;
    bool coroutineInProgress;

    public void OnEnableState()
    {
        sm = GetComponentInParent<StateMachine>();
        continueButton.onClick.AddListener(EndGame);

        winText.SetActive(myWin);
        lostText.SetActive(!myWin);

        gameObject.SetActive(true);
    }

    public void OnDisableState()
    {
        gameObject.SetActive(false);
    }

    void EndGame()
    {
        if (sm.game.isFinished)
        {
            DeleteGame();
        }
        else
        {
            UpdateGame();
        }
    }

    void DeleteGame()
    {
        if (!coroutineInProgress)
        {
            coroutineInProgress = true;

            var route = "http://localhost:5000/api/games/" + sm.player;

            StartCoroutine(sm.pm.Lookup<Game>(UnityWebRequest.Delete(route), x =>
            {
                coroutineInProgress = false;
                sm.ChangeState(nextState);
            }));
        }
    }

    public void UpdateGame()
    {
        if (!coroutineInProgress)
        {
            coroutineInProgress = true;

            sm.game.round++;
            sm.game.lastDate = DateTime.Now.Ticks;

            sm.game.isFinished = true;

            if(sm.game.username_A == sm.player)
            {
                sm.game.username_A = "";
            }
            else
            {
                sm.game.username_B = "";
            }

            var route = "http://localhost:5000/api/games/" + JsonUtility.ToJson(sm.game);

            Debug.Log("Update: " + JsonUtility.ToJson(sm.game));

            StartCoroutine(sm.pm.Lookup<Game>(UnityWebRequest.Put(route, default(Byte[])), x =>
            {
                coroutineInProgress = false;
                sm.ChangeState(nextState);
            }));
        }
    }
}
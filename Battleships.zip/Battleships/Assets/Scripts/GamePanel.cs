﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class GamePanel : MonoBehaviour
{
    public Text opponentText;
    public Text roundText;
    public Text timeText;

    public Button playButton;
    public GameObject playText;
    public GameObject waitText;
}

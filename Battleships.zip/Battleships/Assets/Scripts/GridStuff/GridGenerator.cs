﻿using UnityEngine;
using UnityEngine.UI;

public class GridGenerator : MonoBehaviour
{
    public float nodeSize = 50;
    public float space = 5;
    public float scale = 1;
    public GameObject nodePrefab;

    [Header("Debug")]
    public Transform panels;
    public Image[] nodeImages;
    public float scaledNodeSize;
    public Vector2 nodeScale;

    public Vector3 GetNearestNodePosition(Vector3 position)
    {
        return (Vector3)GetNodeAtPosition(position) * scaledNodeSize + panels.position;
    }

    public Vector3Int GetNodeAtPosition(Vector3 position)
    {
        position -= panels.position;

        int x = Mathf.RoundToInt(position.x / scaledNodeSize);
        int y = Mathf.RoundToInt(position.y / scaledNodeSize);

        return new Vector3Int(x, y, 0);
    }

    public bool IsInsideGrid(Vector3 position)
    {
        var node = GetNodeAtPosition(position);
        return node.x >= 0 && node.x < 10 && node.y >= 0 && node.y < 10;
    }

    public void Generate()
    {
        scaledNodeSize = scale * (nodeSize + space);

        nodeScale = scale * nodeSize * Vector2.one;

        panels = new GameObject("Panels").transform;
        panels.parent = transform;

        panels.position = transform.position - (Vector3) Vector2.one * scaledNodeSize * .5f * (10 - 1);

        nodeImages = new Image[100];

        for (int x = 0; x < 10; x++)
        {
            for (int y = 0; y < 10; y++)
            {
                var ob = Instantiate(nodePrefab, new Vector3(x, y) * scaledNodeSize + panels.position, Quaternion.identity, panels);
                ob.transform.localScale = nodeScale;
                ob.tag = tag;
                nodeImages[x * 10 + y] = ob.GetComponent<Image>();
            }
        }
    }
}
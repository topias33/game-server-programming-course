﻿using UnityEngine;
using UnityEngine.UI;

public class ShipGenerator : MonoBehaviour
{
    /*
    Carrier, which has five holes
    Battleship, which has four holes
    Cruiser, which has three holes
    Submarine, which has three holes
    Destroyer, which has two holes
     */

    public enum ShipType
    {
        Carrier, Battleship, Cruiser, Submarine, Destroyer
    }
    
    public GridGenerator grid;
    public ShipType shipType = ShipType.Destroyer;

    Transform shipParts;

    [HideInInspector]
    public int lenght;

    [HideInInspector]
    public Image[] images;

    Vector3 originalPosition;
    Quaternion originalRotation;

    void Start() 
    {
        originalPosition = transform.position;
        originalRotation = transform.rotation;
    }

    public void Relocate()
    {
        transform.position = originalPosition;
        transform.rotation = originalRotation;
    }

    public void Generate()
    {
        shipParts = new GameObject("shipParts").transform;
        shipParts.parent = transform;

        switch(shipType)
        {
            case ShipType.Carrier:
                lenght = 5;
                break;
            case ShipType.Battleship:
                lenght = 4;
                break;
            case ShipType.Cruiser:
                lenght = 3;
                break;
            case ShipType.Submarine:
                lenght = 3;
                break;
            case ShipType.Destroyer:
                lenght = 2;
                break;
        }

        images = new Image[lenght];

        for (int i = 0; i < lenght; i++)
        {
            var ob = Instantiate(grid.nodePrefab, transform.position + Vector3.right * (i * grid.scaledNodeSize), Quaternion.identity, shipParts);
            ob.transform.localScale = grid.nodeScale;
            ob.tag = "Ship";
            images[i] = ob.GetComponent<Image>();
        }
    }
}
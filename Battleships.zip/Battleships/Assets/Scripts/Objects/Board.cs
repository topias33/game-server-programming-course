﻿public class Board
{
    public string shipsString;
    public string hitsString;

    public int[,] ships = new int[10, 10];
    public int[,] hits = new int[10, 10];

    public string ArrayToString(int[,] arr)
    {
        string str = "";

        for (int x = 0; x < 10; x++)
        {
            for (int y = 0; y < 10; y++)
            {
                str += arr[x,y];
            }
        }

        return str;
    }

    public int[,] StringToArray(string str)
    {
        int[,] arr = new int[10,10];

        if (str == "" || str == null) return arr;

        int i = 0;
        for (int x = 0; x < 10; x++)
        {
            for (int y = 0; y < 10; y++)
            {
                arr[x,y] = (int)char.GetNumericValue(str[i++]);
            }
        }

        return arr;
    }
}
﻿using System;
using System.Collections.Generic;

[Serializable]
public class GameList
{
    public List<Game> games;
}
using System;

[Serializable]
public class Player
{
    public string username;
}
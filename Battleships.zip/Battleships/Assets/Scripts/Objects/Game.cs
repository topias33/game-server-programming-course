﻿using System;

[Serializable]
public class Game
{
    public string id;
    public int round;
    public long lastDate;

    public bool isFinished;

    public string username_A;
    public string username_B;

    public string shipsString_A;
    public string hitsString_A;

    public string shipsString_B;
    public string hitsString_B;

    public Board board_A = new Board();
    public Board board_B = new Board();

    public string GetOpponentName(string username)
    {
        string name = username == username_A ? username_B : username_A;
        if (name == null || name.Length == 0) name = "Waiting opponent...";
        return name;
    }

    public int GetMinutes()
    {
        return DateTime.Now.Subtract(new DateTime(lastDate)).Minutes;
    }

    public bool IsMyTurn(string username)
    {
        if (round % 2 == 0)
            return username_A == username;
        return username_B == username;
    }

    public Board GetBoard(string username)
    {
        return username == username_A ? board_A : board_B;
    }

    public void SetBoard(string username, Board board)
    {
        if (username == username_A)
            board_A = board;
        else
            board_B = board;
    }

    public void ConvertData(bool toString)
    {
        if (toString)
        {
            shipsString_A = board_A.ArrayToString(board_A.ships);
            hitsString_A = board_A.ArrayToString(board_A.hits);
            shipsString_B = board_B.ArrayToString(board_B.ships);
            hitsString_B = board_B.ArrayToString(board_B.hits);
        }
        else
        {
            board_A.ships = board_A.StringToArray(shipsString_A);
            board_A.hits = board_A.StringToArray(hitsString_A);
            board_B.ships = board_B.StringToArray(shipsString_B);
            board_B.hits = board_B.StringToArray(hitsString_B);
        }
    }
}
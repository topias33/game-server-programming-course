﻿// using UnityEngine;
// using UnityEngine.SceneManagement;
// using System.Linq;

// public class GameController : GenericSingleton<GameController>
// {
//     public int gridSize = 10;

//     [HideInInspector]
//     public Postman postman = new Postman();

//     IState sceneCtrl;

//     bool sceneCtrlLoaded = false;

//     void Start()
//     {
//         SceneManager.sceneLoaded += (Scene s, LoadSceneMode mode) => sceneCtrlLoaded = true;

//         NextScene(0);
//     }

//     void Update()
//     {
//         if (!sceneCtrlLoaded) return;

//         if (sceneCtrl == null)
//         {
//             sceneCtrl = GameObject.FindObjectsOfType<MonoBehaviour>().OfType<IState>().FirstOrDefault();
//             if (sceneCtrl != null) 
//                 sceneCtrl.OnEnable(this);
//             else return;
//         }

//         sceneCtrl.OnDisable();
//     }

//     public void NextScene(string sceneName)
//     {
//         NextScene(SceneManager.GetSceneByName(sceneName).buildIndex);
//     }

//     public void NextScene(int sceneIndex)
//     {
//         sceneCtrlLoaded = false;
//         sceneCtrl = null;
//         SceneManager.LoadSceneAsync(sceneIndex);
//     }
// }
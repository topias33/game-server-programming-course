using UnityEngine;
using UnityEngine.EventSystems;

public class UIDragTest : EventTrigger
{
    private bool dragging;
    Vector3 originPos;
    Vector3 lastPos;

    private void Start()
    {
        originPos = transform.position;
        lastPos = originPos;
    }

    public void Update()
    {
        if (dragging)
        {
            transform.position = new Vector2(Input.mousePosition.x, Input.mousePosition.y);
        }
    }

    public override void OnPointerDown(PointerEventData eventData)
    {
        lastPos = eventData.position;

        dragging = true;
    }

    public override void OnPointerUp(PointerEventData eventData)
    {
        dragging = false;

        Debug.Log(transform.localPosition.x);

        if (transform.localPosition.x > 0)
        {
            lastPos = transform.position;
        }
        else
        {
            transform.position = lastPos;
        }
    }
}

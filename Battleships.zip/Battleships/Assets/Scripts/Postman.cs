﻿using System;
using System.Collections;
using UnityEngine;
using UnityEngine.Networking;

public class Postman : MonoBehaviour
{
    UnityWebRequest _req;

    public IEnumerator Lookup<T>(UnityWebRequest req, Action<T> action)
    {
        if (_req != null && !_req.isDone)
            yield break;

        _req = req;

        yield return _req.SendWebRequest();

        while (!_req.isDone)
            yield return null;

        Debug.Log(string.Format("Result: [{0}]", _req.downloadHandler.text));

        action(JsonUtility.FromJson<T>(_req.downloadHandler.text));
    }
}

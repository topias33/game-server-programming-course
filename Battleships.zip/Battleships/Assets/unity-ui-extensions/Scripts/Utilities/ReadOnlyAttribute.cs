﻿/// Credit tanoshimi
/// Sourced from - https://forum.unity3d.com/threads/read-only-fields.68976/

namespace UnityEngine.UI.Extensions
{
    public class ReadOnlyAttribute : PropertyAttribute { }
}
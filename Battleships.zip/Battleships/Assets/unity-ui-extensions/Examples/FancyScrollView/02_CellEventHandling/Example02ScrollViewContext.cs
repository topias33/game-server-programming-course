﻿namespace UnityEngine.UI.Extensions.Examples
{
    public class Example02ScrollViewContext
    {
        public System.Action<Example02ScrollViewCell> OnPressedCell;
        public int SelectedIndex;
    }
}

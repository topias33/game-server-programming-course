﻿namespace UnityEngine.UI.Extensions.Examples
{
    public class Example03CellDto
    {
        public string Message;
    }
}

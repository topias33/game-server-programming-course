﻿namespace UnityEngine.UI.Extensions.Examples
{
    public class Example03ScrollViewContext
    {
        public System.Action<Example03ScrollViewCell> OnPressedCell;
        public int SelectedIndex;
    }
}

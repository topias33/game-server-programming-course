namespace Assignment_2
{
    public class PlayerFromAnotherGame : IPlayer
    {
        public int Score { get; set; }
    }
}
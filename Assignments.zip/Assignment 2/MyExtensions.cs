using System.Linq;
using Assignment_2;

namespace ExtensionMethods
{
    public static class MyExtensions
    {
        public static Item GetHighestLevelItem(this Player player)
        {
            return player.Items.OrderBy( x => x.Level).Last();
        }
    }
}
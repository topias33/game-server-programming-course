using System;
namespace Assignment_2
{
    public class Item
    {
        public Guid Id { get; set; }
        public int Level { get; set; }
    }
}
using System.Linq;
using System.Collections.Generic;
using System;

namespace Assignment_2
{
    public class Game<T> where T : IPlayer
    {
        private List<T> _players;

        public Game(List<T> players) => _players = players;

        public T[] GetTop10Players() => _players.OrderByDescending(x => x.Score).Take(10).ToArray();
    }
}
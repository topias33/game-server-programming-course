using System.Threading.Tasks;
using System.Net.Http;
using Newtonsoft.Json;
using System.Linq;

namespace Assignment_1
{
    public class RealTimeCityBikeDataFetcher : ICityBikeDataFetcher
    {
        const string api = "http://api.digitransit.fi/routing/v1/routers/hsl/bike_rental";

        public async Task<int> GetBikeCountInStation(string stationName)
        {
            if (stationName.Any(char.IsDigit))
            {
                throw new System.ArgumentException("Station name may not have numbers.");
            }

            HttpClient client = new HttpClient();
            string json = await client.GetStringAsync(api);
            var bikeRentalStationList = JsonConvert.DeserializeObject<BikeRentalStationList>(json);
            
            foreach (var station in bikeRentalStationList.stations)
            {
                if (station.name == stationName)
                {
                    return station.bikesAvailable;
                }
            }

            throw new NotFoundException("Station not found.");
        }
    }
}
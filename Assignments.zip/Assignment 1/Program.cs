﻿using System.Linq;
using System;
using System.Threading.Tasks;

// dotnet run Korjaamo

namespace Assignment_1
{
    class Program
    {
        static void Main(string[] args)
        {
            ICityBikeDataFetcher fetcher;

            switch (args.First().ToLower())
            {
                case "offline": case "off":
                    fetcher = new OfflineCityBikeDataFetcher();
                    break;
                default:
                    fetcher = new RealTimeCityBikeDataFetcher();
                    break;
            }

            try 
            {
                int result = fetcher.GetBikeCountInStation(args.Last()).Result;
                Console.WriteLine("Bikes available: " + result);
            }
            catch(ArgumentException ex)
            {
                Console.WriteLine("Invalid argument: ", ex);
            }
            catch(NotFoundException ex)
            {
                Console.WriteLine("Not found: ", ex);
            }
        }
    }
}

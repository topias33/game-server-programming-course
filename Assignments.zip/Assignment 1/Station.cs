namespace Assignment_1
{
    public class Station
    {
        public string name;
        public int bikesAvailable;
    }
}
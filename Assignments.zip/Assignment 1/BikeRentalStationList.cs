namespace Assignment_1
{
    public class BikeRentalStationList
    {
        public Station[] stations;
    }
}
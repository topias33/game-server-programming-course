using System;

namespace Assignment_1
{
    public class NotFoundException: Exception 
    {
        public NotFoundException(String message) : base(message) {}
    }
}
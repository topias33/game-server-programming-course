using System;

public static class ObjectExtensionMethods
{
    public static void CopyPropertiesFrom(this object to, object from)
    {
        var fromProperties = from.GetType().GetProperties();
        var toProperties = to.GetType().GetProperties();

        foreach (var fromProperty in fromProperties)
        {
            if (fromProperty.GetValue(from) == null) continue;

            Type fromType = GetNullableType(fromProperty.PropertyType);

            foreach (var toProperty in toProperties)
            {
                if (fromProperty.Name == toProperty.Name && fromType == GetNullableType(toProperty.PropertyType))
                {
                    toProperty.SetValue(to, fromProperty.GetValue(from));
                    break;
                }
            }
        }
    }

    static Type GetNullableType(Type type)
    {
        return Nullable.GetUnderlyingType(type) ?? type;
    }
}
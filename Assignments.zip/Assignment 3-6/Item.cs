using System;
using System.ComponentModel.DataAnnotations;
using static CustomValidation;

public enum ItemType
{
    SWORD,
    POTION,
    SHIELD
}

public class Item
{
    public Guid Id {get; set;}

    [EnumDataType(typeof(ItemType))]
    public ItemType Type {get; set;}

    [Range(1, 99)]
    public int Level {get; set;}

    [CheckDate]
    public DateTime CreationDate {get; set;}

    public Item(ItemType type = ItemType.SWORD, int level = 1)
    {
        this.Id = Guid.NewGuid();
        this.Level = level;
        this.Type = type;
        this.CreationDate = DateTime.Now;
    }
}

public class NewItem
{
    [EnumDataType(typeof(ItemType))]
    public ItemType? Type {get; set;}

    [Range(1, 99)]
    public int? Level {get; set;}
}

public class UpdatedItem
{
    [EnumDataType(typeof(ItemType))]
    public ItemType? Type {get; set;}
    
    [Range(1, 99)]
    public int? Level {get; set;}
}
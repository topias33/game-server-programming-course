using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Filters;

public class LevelTooLowFilter : ExceptionFilterAttribute
{
    public override void OnException(ExceptionContext context)
    {
        if (context.Exception is LevelTooLowException)
        {
            //context.HttpContext.Response.StatusCode = 404;
            context.HttpContext.Response.WriteAsync(context.Exception.Message);
        }
    }
}
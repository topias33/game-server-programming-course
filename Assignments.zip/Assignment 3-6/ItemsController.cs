using System;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using static CustomValidation;

[Route("api/players/{playerId}/[controller]")]
[ApiController]
public class ItemsController : Controller
{
    IRepository _repository;

    public ItemsController(IRepository repository)
    {
        _repository = repository;
    }

    [HttpPost]
    public Task<Item> Create(Guid playerId, [FromBody] NewItem newItem)
    {
        var item = new Item();
        item.CopyPropertiesFrom(newItem);
        return _repository.CreateItem(playerId, item);
    }

    [HttpGet("{itemId:guid}")]
    public Task<Item> Get(Guid playerId, Guid itemId) => _repository.GetItem(playerId, itemId);

    [HttpGet]
    public Task<Item[]> GetAll(Guid playerId) => _repository.GetAllItems(playerId);

    [HttpPost("{itemId}")]
    public Task<Item> Modify(Guid playerId, Guid itemId, [FromBody] UpdatedItem modifiedItem)
    {
        var item = new Item();
        item.CopyPropertiesFrom(modifiedItem);
        item.Id = itemId;
        return _repository.UpdateItem(playerId, item);
    }

    [HttpDelete("{itemId}")]
    public Task<Item> Delete(Guid playerId, Guid itemId) => _repository.DeleteItem(playerId, itemId);
}
using System;
using System.ComponentModel.DataAnnotations;
using System.Diagnostics;

public class CustomValidation
{
    public sealed class CheckDate : ValidationAttribute
    {
        protected override ValidationResult IsValid(object value, ValidationContext validationContext)
        {
            if ((DateTime)value > DateTime.Now)
                return new ValidationResult("Date is in the future.");
            return ValidationResult.Success;
        }
    }

    // public sealed class CheckSword : ValidationAttribute
    // {


    //     protected override ValidationResult IsValid(object value, ValidationContext validationContext)
    //     {
    //         // var property = validationContext.ObjectType.GetProperty(NewPlayer)

    //         // if ((a[Item].Type == ItemType.SWORD && ((Player)validationContext).Level >= 3)
    //         // {
                
    //         //     //...
    //         // }

    //         return ValidationResult.Success;
    //     }
    // }
}
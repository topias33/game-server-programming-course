using System;
using System.Collections.Generic;

public class Player
{
    public Guid Id {get; set;}
    public string Name {get; set;}
    public int Score {get; set;}
    public int Level {get; set;}
    public bool IsBanned {get; set;}
    public DateTime CreationTime {get; set;}

    public List<Item> Items {get; set;}
    public List<Tag> Tags {get; set;}

    public Player(string name = "", int score = 0, int level = 1, bool isBanned = false)
    {
        this.Id = Guid.NewGuid();
        this.Name = name;
        this.Score = score;
        this.Level = level;
        this.IsBanned = isBanned;
        this.CreationTime = DateTime.Now;

        this.Items = new List<Item>();

        Tags = new List<Tag>();

        var max = Enum.GetNames(typeof(Tag)).Length;
        var r = new Random();
        var length = r.Next(0, max + 1);
        for (int i = 0; i < length; i++)
        {
            Tags.Add((Tag)r.Next(0, max + 1));
        }
    }
}

public class NewPlayer
{
    public string Name {get; set;}
    public int? Score {get; set;}
    public int? Level {get; set;}
}

public class UpdatedPlayer
{
    public string Name {get; set;}
    public int? Score {get; set;}
    public int? Level {get; set;}
    public bool? IsBanned {get; set;}
}

public enum Tag
{
    RED, GREEN, BLUE
}
using System.Linq.Expressions;
using System;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;

[Route("api/[controller]")]
[ApiController]
public class PlayersController : Controller
{
    IRepository _repository;

    public PlayersController(IRepository repository)
    {
        _repository = repository;

        // if (GetAll().Result.Length == 0)
        // {
        //     _repository.DeleteAll();

        //     for (int i = 0; i < 3; i++)
        //     {
        //         var dummy = new NewPlayer();
        //         dummy.Name = "Dummy" + i;
        //         Create(dummy);
        //     }
        // }
    }

    [HttpPost]
    public Task<Player> Create([FromBody]NewPlayer newPlayer)
    {
        var player = new Player();
        player.CopyPropertiesFrom(newPlayer);
        return _repository.CreatePlayer(player);
    }

    [HttpGet("{name}")]
    public Task<Player> GetWithName(String name) => _repository.GetWithName(name);

    [HttpGet("{playerId:guid}")]
    public Task<Player> Get(Guid playerId) => _repository.GetPlayer(playerId);

    [HttpGet]
    public Task<Player[]> GetAll([FromQuery] int? minScore = null) => _repository.GetAllPlayers(minScore);

    [HttpGet("{tag:int}")]
    public Task<Player[]> GetTagged(Tag tag) => _repository.GetTagged(tag);

    [HttpPost("{playerId}")]
    public Task<Player> Update(Guid playerId, [FromBody] UpdatedPlayer updatedPlayer)
    {
        var player = new Player();
        player.CopyPropertiesFrom(updatedPlayer);
        player.Id = playerId;
        return _repository.UpdatePlayer(player);
    }

    [HttpDelete("{playerId}")]
    public Task<Player> Delete(Guid playerId) => _repository.DeletePlayer(playerId);

    [HttpDelete]
    public void DeleteAll() => _repository.DeleteAll();

    [HttpPut("{itemCount:int}")]
    public Task<Player> GetWithCount(int itemCount) => _repository.GetWithCount(itemCount);
}